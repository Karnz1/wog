import memory_game, currency_roulette_game, guess_game


def welcome():
    name = input("Enter your name: ")
    print(f'Hi {name} and welcome to the World of Games: The Epic Journey')


def start_play():
    game_options = [1, 2, 3]
    difficulty_options = [1, 2, 3, 4, 5]
    valid_game_option_not_selected = True
    valid_difficulty_option_not_selected = True
    game_to_play = 0
    difficulty_level = 0
    while valid_game_option_not_selected:
        game = input("""Please choose a game to play:
                1. Memory Game - a sequence of numbers will appear for 1 second and you have to guess it back.
                2. Guess Game - guess a number and see if you chose like the computer.
                3. Currency Roulette - try and guess the value of a random amount of USD in ILS.
                """)
        if game.isdigit() and int(game) in game_options:
            valid_game_option_not_selected = False
            print(game)
            game_to_play = int(game)
            break
        print("try again")

    while valid_difficulty_option_not_selected:
        difficulty = input("Select a difficulty level between 1 and 5: ")
        if difficulty.isdigit() and int(difficulty) in difficulty_options:
            valid_difficulty_option_not_selected = False
            print(difficulty)
            difficulty_level = int(difficulty)
            break
        print("try again")

    if game_to_play == 1:
        return memory_game.play(difficulty_level)
    elif game_to_play == 2:
        return guess_game.play(difficulty_level)
    elif game_to_play == 3:
        return currency_roulette_game.play(difficulty_level)

